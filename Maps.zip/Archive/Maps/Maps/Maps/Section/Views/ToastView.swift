import UIKit

class ToastView: NSObject {
    
}
